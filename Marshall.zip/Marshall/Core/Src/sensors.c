// sensors.c
#include "sensors.h"
#include "fsm.h"
#include "lcd_ui.h"
#include "config.h"
#include "main.h"

static uint32_t last_press_p1 = 0;
static uint32_t last_press_p2 = 0;
static uint32_t last_menu = 0;

void Sensors_Init(void)
{
    // CubeMX inicializa los GPIOs/EXTI. No hay que hacer nada más aquí.
}

/* Este es el wrapper que definimos para la callback HAL_GPIO_EXTI_Callback.
   En stm32f4xx_it.c la función HAL_GPIO_EXTI_Callback llamará a esta.
*/
void HAL_GPIO_EXTI_Callback_Custom(uint16_t GPIO_Pin)
{
    uint32_t t = HAL_GetTick();

    if (GPIO_Pin == TRIGGER1_Pin) {
        if ((t - last_press_p1) > DEBOUNCE_MS) {
            last_press_p1 = t;
            fsm_event_player_press(1, t);
        }
    } else if (GPIO_Pin == TRIGGER2_Pin) {
        if ((t - last_press_p2) > DEBOUNCE_MS) {
            last_press_p2 = t;
            fsm_event_player_press(2, t);
        }
    } else if (GPIO_Pin == BTN_UP_Pin || GPIO_Pin == BTN_DOWN_Pin || GPIO_Pin == BTN_SELECT_Pin) {
        if ((t - last_menu) > DEBOUNCE_MS) {
            last_menu = t;
            lcd_ui_button_event(GPIO_Pin);
        }
    }
}
