// lcd_ui.c
#include "lcd_ui.h"
#include "main.h"
#include "string.h"
#include "stdio.h"

extern I2C_HandleTypeDef hi2c1;

/* PCF8574 I2C address usual: 0x27 << 1 (7-bit 0x27) - puede variar (0x3F) */
#ifndef LCD_I2C_ADDR
#define LCD_I2C_ADDR (0x27 << 1)
#endif

/* LCD pins via PCF8574: D4..D7, EN, RW, RS, BL mapping commonly:
   P7  P6  P5  P4  P3  P2  P1  P0
   D7  D6  D5  D4  BL  EN  RW  RS
   Ajusta si tu módulo usa otro mapeo.
*/
static uint8_t lcd_addr = LCD_I2C_ADDR;
static uint8_t lcd_backlight = 0x10; // bit P4 as backlight (adjust if needed)

static void lcd_write4(uint8_t nibble, uint8_t control)
{
    uint8_t data = ((nibble & 0x0F) << 4) | control | lcd_backlight;
    // pulse EN
    uint8_t tmp[1];
    tmp[0] = data | 0x04; // EN = 1
    HAL_I2C_Master_Transmit(&hi2c1, lcd_addr, tmp, 1, 50);
    tmp[0] = data & ~0x04; // EN = 0
    HAL_I2C_Master_Transmit(&hi2c1, lcd_addr, tmp, 1, 50);
}

static void lcd_send(uint8_t value, uint8_t mode)
{
    // mode: RS bit (0 cmd, 1 data)
    lcd_write4((value >> 4) & 0x0F, mode);
    lcd_write4(value & 0x0F, mode);
}

void lcd_clear(void)
{
    lcd_send(0x01, 0);
    HAL_Delay(2); // inicial, corto y aceptable para init/clear
}

void lcd_put_cur(uint8_t row, uint8_t col)
{
    uint8_t addr = (row == 0) ? (0x80 + col) : (0xC0 + col);
    lcd_send(addr, 0);
}

void lcd_send_string(const char *str)
{
    while (*str) {
        lcd_send((uint8_t)*str++, 0x01); // RS = 1
    }
}

/* Inicialización básica 4-bit por PCF8574 */
void LCD_Init_Driver(void)
{
    HAL_Delay(50);
    // Init sequence
    lcd_write4(0x03, 0);
    HAL_Delay(5);
    lcd_write4(0x03, 0);
    HAL_Delay(5);
    lcd_write4(0x03, 0);
    HAL_Delay(1);
    lcd_write4(0x02, 0); // set 4-bit mode

    // Function set: 2 lines, 5x8 dots
    lcd_send(0x28, 0);
    // Display on, cursor off, blink off
    lcd_send(0x0C, 0);
    // Clear
    lcd_clear();
    // Entry mode set
    lcd_send(0x06, 0);
}

static game_config_t cfg_local;

game_config_t* LCD_GetConfig(void) { return &cfg_local; }

void LCD_ShowMainMenu(void)
{
    lcd_clear();
    lcd_put_cur(0,0);
    lcd_send_string("DUEL WEST");
    char buf[16];
    snprintf(buf, sizeof(buf), "Mode:%d R:%d", cfg_local.mode, cfg_local.rounds);
    lcd_put_cur(1,0);
    lcd_send_string(buf);
}

void LCD_ShowWaiting(void)
{
    lcd_clear();
    lcd_put_cur(0,0);
    lcd_send_string("Preparados...");
    lcd_put_cur(1,0);
    lcd_send_string("Esperando señal");
}

void LCD_ShowRoundWinner(uint8_t player, uint8_t p1, uint8_t p2)
{
    char buf[17];
    lcd_clear();
    if(player == 0) lcd_send_string("EMPATE");
    else {
        snprintf(buf, sizeof(buf), "Gana J%d", player);
        lcd_put_cur(0,0);
        lcd_send_string(buf);
    }
    snprintf(buf, sizeof(buf), "P:%d - %d", p1, p2);
    lcd_put_cur(1,0);
    lcd_send_string(buf);
}

/* Menú simple: botones manejan modo y rondas. */
void lcd_ui_tick(void)
{
    // opcional: refresco periódico (no necesario)
}

void lcd_ui_button_event(uint16_t GPIO_Pin)
{
    // Mapea pines definidos en main.h (BTN_UP_Pin etc.)
    if (GPIO_Pin == BTN_UP_Pin) {
        if (cfg_local.mode < MODE_CUSTOM) cfg_local.mode++;
    } else if (GPIO_Pin == BTN_DOWN_Pin) {
        if (cfg_local.mode > 0) cfg_local.mode--;
    } else if (GPIO_Pin == BTN_SELECT_Pin) {
        // start game: la FSM escucha directamente (ver fsm_start_game)
        // Para simplicidad, no hacemos nada aquí más que mostrar
    }
    LCD_ShowMainMenu();
}

/* Inicialización pública */
void lcd_ui_init_defaults(void)
{
    cfg_local.mode = MODE_CLASSIC;
    cfg_local.rounds = 3;
    cfg_local.min_delay_ms = MIN_RANDOM_MS;
    cfg_local.max_delay_ms = MAX_RANDOM_MS;
}
