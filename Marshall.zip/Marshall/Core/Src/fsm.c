// fsm.c
#include "fsm.h"
#include "peripherals.h"
#include "actuators.h"
#include "lcd_ui.h"
#include "stdio.h"

/* variables de estado */
static game_state_t state;
static game_config_t cfg;
static uint8_t scores[2];
static uint8_t round_num;
static uint8_t round_winner;
static volatile uint8_t timer2_fired = 0;

/* RNG xorshift */
static uint32_t rng_state = 0xA5A5A5A5;
static uint32_t rng32(void){
    uint32_t x = rng_state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    rng_state = x;
    return x;
}
static uint32_t rand_between(uint32_t min, uint32_t max){
    if (max <= min) return min;
    return min + (rng32() % (max - min + 1));
}

void fsm_init(void)
{
    state = GS_IDLE;
    scores[0] = scores[1] = 0;
    round_num = 0;
    round_winner = 0;
    // semilla RNG con ADC y tick actual
    uint16_t v = ADC_ReadPot();
    rng_state ^= ((uint32_t)v << 16) | (uint32_t)HAL_GetTick();
    Actuators_Init();
    LCD_Init_Driver();
    lcd_ui_init_defaults();
    LCD_ShowMainMenu();
}

/* start game desde menú */
void fsm_start_game(game_config_t *cfg_in)
{
    cfg = *cfg_in;
    scores[0] = scores[1] = 0;
    round_num = 0;
    state = GS_WAIT_RANDOM;
    // generar primer delay
    uint32_t rnd = rand_between(cfg.min_delay_ms, cfg.max_delay_ms);
    Timer2_Start_ms(rnd);
    LCD_ShowWaiting();
}

/* Invocado desde TIM2 ISR (HAL_TIM_PeriodElapsedCallback) */
void fsm_timer2_callback(void)
{
    timer2_fired = 1;
}

/* Invocado desde EXTI wrapper */
void fsm_event_player_press(uint8_t player, uint32_t tick_ms)
{
    if (state == GS_WAIT_RANDOM || state == GS_SIGNAL_ON || state == GS_WAIT_PRESS) {
        if (round_winner == 0) {
            round_winner = player;
            state = GS_EVALUATE;
        }
    } else {
        // disparo antes de la señal (falso): penalizar (el otro jugador gana la ronda)
        if (state == GS_WAIT_RANDOM) {
            // penaliza al que disparó: el otro jugador gana
            uint8_t other = (player == 1) ? 2 : 1;
            round_winner = other;
            state = GS_EVALUATE;
            // detener timer single-shot si estaba activo
            Timer2_Stop();
        }
    }
}

void fsm_tick(void)
{
    switch(state) {
        case GS_IDLE:
            // queda esperando start desde menú
            break;

        case GS_WAIT_RANDOM:
            if (timer2_fired) {
                timer2_fired = 0;
                // Señal ON
                Led_Central_On();
                Buzzer_PlayTone(1200, 60); // tono corto de señal (no bloqueante)
                // pasamos a esperar disparos
                round_winner = 0;
                state = GS_WAIT_PRESS;
            }
            break;

        case GS_WAIT_PRESS:
            // la llegada de un EXTI pone round_winner y cambia a EVALUATE
            break;

        case GS_EVALUATE:
            if (round_winner != 0) {
                // asignar punto
                if (round_winner == 1) scores[0]++; else scores[1]++;
                // mostrar resultado y LEDs
                Led_Central_Off();
                Led_Player_Show(round_winner);
                char buf[16];
                snprintf(buf, sizeof(buf), "Ronda %d: J%d", round_num+1, round_winner);
                LCD_ShowMessage(buf);
                // melodía ganadora corta
                if (round_winner == 1) {
                    const uint32_t freq[] = {880, 0};
                    const uint32_t dur[] = {120, 0};
                    Buzzer_PlayMelody(freq, dur);
                } else {
                    const uint32_t freq[] = {660, 0};
                    const uint32_t dur[] = {120, 0};
                    Buzzer_PlayMelody(freq, dur);
                }
                state = GS_SHOW_ROUND;
            } else {
                state = GS_SHOW_ROUND;
            }
            break;

        case GS_SHOW_ROUND:
            // avanzamos ronda
            round_num++;
            // comprobamos fin: quien alcanza cfg.rounds gana
            if (scores[0] >= cfg.rounds || scores[1] >= cfg.rounds) {
                state = GS_ENDGAME;
            } else {
                // preparar próxima ronda
                Led_ClearAll();
                uint32_t rnd = rand_between(cfg.min_delay_ms, cfg.max_delay_ms);
                Timer2_Start_ms(rnd);
                LCD_ShowWaiting();
                state = GS_WAIT_RANDOM;
            }
            break;

        case GS_ENDGAME:
            // anunciar ganador
            if (scores[0] > scores[1]) LCD_ShowRoundWinner(1, scores[0], scores[1]);
            else if (scores[1] > scores[0]) LCD_ShowRoundWinner(2, scores[0], scores[1]);
            else LCD_ShowRoundWinner(0, scores[0], scores[1]);
            // reset al menú
            state = GS_IDLE;
            LCD_ShowMainMenu();
            break;

        default:
            state = GS_IDLE;
            break;
    }

    // actualizar buzzer (no-bloqueante)
    Buzzer_Update();
}
