/* main.c - fragmentos importantes */
#include "main.h"
#include "peripherals.h"
#include "sensors.h"
#include "fsm.h"
#include "lcd_ui.h"

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    /* Inicializaciones generadas por CubeMX */
    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_ADC1_Init();
    MX_TIM2_Init(); // timer base para delays random
    MX_TIM3_Init(); // timer para PWM buzzer

    /* Inicializaciones de nuestros módulos */
    Peripherals_Init();
    Sensors_Init();
    fsm_init();

    /* bucle principal */
    while (1)
    {
        fsm_tick();
        lcd_ui_tick();  // mantiene UI responsiva
        // no HAL_Delay en el bucle principal
    }
}

/* Interrupciones y callbacks - añade/edita en tu archivo it.c o main.c según convenga */

/* EXTI: CubeMX ya llama a HAL_GPIO_EXTI_Callback cuando hay EXTI.
   Proporcionamos aquí la función para delegar a nuestro manejador.
*/
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    // delega a nuestro wrapper (debounce incluido)
    HAL_GPIO_EXTI_Callback_Custom(GPIO_Pin);
}

/* TIM2 period elapsed -> single-shot timer fired */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM2) {
        // detener timer y avisar FSM
        Timer2_Stop();
        fsm_timer2_callback();
    }
}
