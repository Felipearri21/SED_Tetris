#include "state_machine.h"
#include "game.h"
#include "utils.h"
#include "menu.h"

GameState currentState = STATE_MENU;

void StateMachine_Update(void) {

    switch(currentState)
    {
        case STATE_MENU:
            // manejado en menu.c
            break;

        case STATE_WAIT_RANDOM:
            if(Random_Delay_Expired())
                currentState = STATE_LED_ON;
            break;

        case STATE_LED_ON:
            LED_StartSignal();
            currentState = STATE_SHOOT;
            break;

        case STATE_SHOOT:
            if(triggerJ1_flag) currentState = STATE_RESULT;
            if(triggerJ2_flag) currentState = STATE_RESULT;
            break;

        case STATE_RESULT:
            Show_Result();
            currentState = STATE_RESET;
            break;

        case STATE_RESET:
            Game_Reset();
            break;
    }
}
