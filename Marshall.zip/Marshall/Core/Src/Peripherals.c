// peripherals.c
#include "peripherals.h"
#include "main.h"

extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern I2C_HandleTypeDef hi2c1;

void Peripherals_Init(void)
{
    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_ADC1_Init();
    MX_TIM2_Init();
    MX_TIM3_Init();

    HAL_ADC_Start(&hadc1); // listo para lecturas por polling
    // No arrancamos TIM2 (usado como single-shot)
    // TIM3 configurado por CubeMX para PWM - no arrancamos compare todavía
}

/* Lectura ADC (polling corto, no bloquea más que unos ms) */
uint16_t ADC_ReadPot(void)
{
    HAL_ADC_Stop(&hadc1);
    HAL_ADC_Start(&hadc1);
    if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK) {
        uint16_t v = HAL_ADC_GetValue(&hadc1);
        HAL_ADC_Stop(&hadc1);
        return v;
    }
    HAL_ADC_Stop(&hadc1);
    return 0;
}

/* Timer2 single-shot en ms.
   Asegúrate en CubeMX que TIM2 está configurado con un prescaler para 1ms tick
   (por ejemplo, Prescaler = (SystemCoreClock/1000)-1) y Counter mode up.
*/
void Timer2_Start_ms(uint32_t ms)
{
    __HAL_TIM_DISABLE_IT(&htim2, TIM_IT_UPDATE);
    __HAL_TIM_SET_AUTORELOAD(&htim2, ms);
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_UPDATE);
    __HAL_TIM_ENABLE_IT(&htim2, TIM_IT_UPDATE);
    HAL_TIM_Base_Start(&htim2);
}

void Timer2_Stop(void)
{
    HAL_TIM_Base_Stop(&htim2);
    __HAL_TIM_DISABLE_IT(&htim2, TIM_IT_UPDATE);
}
