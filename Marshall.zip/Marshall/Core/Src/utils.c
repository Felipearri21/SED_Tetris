/*
 * utils.c
 *
 *  Created on: Nov 26, 2025
 *      Author: yanko
 */


