#include "game.h"
#include "state_machine.h"

GameMode currentMode;

void Game_Init(void) {
    currentMode = MODE_DUEL;
}

void Game_Reset(void) {
    currentState = STATE_MENU;
}

void Game_StartDuel(void) {
    currentState = STATE_WAIT_RANDOM;
}
