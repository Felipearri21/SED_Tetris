// actuators.c
#include "actuators.h"
#include "main.h"
#include "stm32f4xx_hal.h"

extern TIM_HandleTypeDef htim3; // PWM for buzzer

/* Pines configurados por CubeMX:
   LED_CENTRAL_Pin, LED_Central_GPIO_Port
   LED_P1_Pin, LED_P1_GPIO_Port
   LED_P2_Pin, LED_P2_GPIO_Port
*/

static uint32_t buzzer_end_ms = 0;
static uint8_t buzzer_active = 0;

void Actuators_Init(void)
{
    HAL_GPIO_WritePin(LED_CENTRAL_GPIO_Port, LED_CENTRAL_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LED_P1_GPIO_Port, LED_P1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LED_P2_GPIO_Port, LED_P2_Pin, GPIO_PIN_RESET);
    // aseguramos PWM parado
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
    HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);
}

/* LEDs */
void Led_Central_On(void){ HAL_GPIO_WritePin(LED_CENTRAL_GPIO_Port, LED_CENTRAL_Pin, GPIO_PIN_SET); }
void Led_Central_Off(void){ HAL_GPIO_WritePin(LED_CENTRAL_GPIO_Port, LED_CENTRAL_Pin, GPIO_PIN_RESET); }
void Led_Player_Show(uint8_t player){
    if(player==1){
        HAL_GPIO_WritePin(LED_P1_GPIO_Port, LED_P1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(LED_P2_GPIO_Port, LED_P2_Pin, GPIO_PIN_RESET);
    } else if(player==2){
        HAL_GPIO_WritePin(LED_P1_GPIO_Port, LED_P1_Pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(LED_P2_GPIO_Port, LED_P2_Pin, GPIO_PIN_SET);
    }
}
void Led_ClearAll(void){
    HAL_GPIO_WritePin(LED_P1_GPIO_Port, LED_P1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LED_P2_GPIO_Port, LED_P2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LED_CENTRAL_GPIO_Port, LED_CENTRAL_Pin, GPIO_PIN_RESET);
}

/* Helper: set PWM frequency (non-blocking) */
static void buzzer_set_frequency(uint32_t freq)
{
    if(freq == 0){
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
        HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);
        buzzer_active = 0;
        return;
    }

    /* Calculamos ARR/PSC de forma simple:
       Asumimos TIM3 base clock = APB1 timer clock (ver SystemClock)
       Para facilidad, mantenemos PSC = 0 y calculamos ARR = timer_clk / freq - 1
       Ajusta si ARR > 0xFFFF/limit (en ese caso incrementar PSC).
    */
    uint32_t timer_clk = HAL_RCC_GetPCLK1Freq();
    // Si APB1 prescaler != 1, timer clock es PCLK1*2; CubeMX suele poner PCLK1 = HCLK/4...
    // para robustez:
#if defined (RCC_CFGR_PPRE1)
    // no portable macro here; asumimos timer clk doubled for APB1 != 1
#endif
    uint32_t arr = (timer_clk / freq) - 1;
    if (arr > 0xFFFF) {
        // simplificado: si demasiado grande, divídelo por 8 y usa PSC=8-1
        uint32_t presc = (arr / 0xFFFF) + 1;
        __HAL_TIM_SET_PRESCALER(&htim3, presc);
        arr = (timer_clk / (presc+1) / freq) - 1;
    }
    __HAL_TIM_SET_AUTORELOAD(&htim3, arr);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, arr/2); // 50% duty
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
    buzzer_active = 1;
}

/* non-blocking play tone */
void Buzzer_PlayTone(uint32_t freq_hz, uint32_t duration_ms)
{
    if (freq_hz == 0 || duration_ms == 0) return;
    buzzer_set_frequency(freq_hz);
    buzzer_end_ms = HAL_GetTick() + duration_ms;
}

/* play melody arrays terminated by 0 freq and 0 duration
   This enqueues in a simple synchronous way: we will play sequentially by calling Buzzer_Update() periodically.
   For simplicity here we implement a simple pointer-based player.
*/
static const uint32_t *mel_freqs = NULL;
static const uint32_t *mel_durs = NULL;
static uint32_t mel_idx = 0;
static uint8_t mel_playing = 0;

void Buzzer_PlayMelody(const uint32_t *freqs, const uint32_t *dur_ms)
{
    mel_freqs = freqs;
    mel_durs = dur_ms;
    mel_idx = 0;
    mel_playing = 1;
    // start first note
    if (mel_freqs && mel_durs) {
        if (mel_freqs[0] == 0 && mel_durs[0] == 0) {
            mel_playing = 0;
            buzzer_set_frequency(0);
        } else {
            buzzer_set_frequency(mel_freqs[0]);
            buzzer_end_ms = HAL_GetTick() + mel_durs[0];
        }
    } else {
        mel_playing = 0;
    }
}

/* Must be called frequently from main loop */
void Buzzer_Update(void)
{
    uint32_t now = HAL_GetTick();
    if (mel_playing) {
        if ((int32_t)(buzzer_end_ms - now) <= 0) {
            // advance
            mel_idx++;
            if (mel_freqs[mel_idx] == 0 && mel_durs[mel_idx] == 0) {
                mel_playing = 0;
                buzzer_set_frequency(0);
            } else {
                buzzer_set_frequency(mel_freqs[mel_idx]);
                buzzer_end_ms = now + mel_durs[mel_idx];
            }
        }
    } else if (buzzer_active) {
        if ((int32_t)(buzzer_end_ms - now) <= 0) {
            buzzer_set_frequency(0);
            buzzer_active = 0;
        }
    }
}
