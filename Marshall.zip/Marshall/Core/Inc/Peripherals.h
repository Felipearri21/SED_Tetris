// peripherals.h
#ifndef PERIPHERALS_H
#define PERIPHERALS_H

#include "stm32f4xx_hal.h"
#include <stdint.h>

void Peripherals_Init(void);
uint16_t ADC_ReadPot(void);
void Timer2_Start_ms(uint32_t ms); // single-shot ms
void Timer2_Stop(void);

#endif
