// fsm.h
#ifndef FSM_H
#define FSM_H

#include "stdint.h"
#include "lcd_ui.h"

typedef enum {
    GS_IDLE,
    GS_WAIT_RANDOM,
    GS_SIGNAL_ON,
    GS_WAIT_PRESS,
    GS_EVALUATE,
    GS_SHOW_ROUND,
    GS_CHECK_WIN,
    GS_ENDGAME
} game_state_t;

void fsm_init(void);
void fsm_tick(void);
void fsm_start_game(game_config_t *cfg);
void fsm_event_player_press(uint8_t player, uint32_t tick_ms);
void fsm_timer2_callback(void);

#endif
