#ifndef STATE_MACHINE_H
#define STATE_MACHINE_H

typedef enum {
    STATE_MENU,
    STATE_WAIT_RANDOM,
    STATE_LED_ON,
    STATE_SHOOT,
    STATE_RESULT,
    STATE_RESET
} GameState;

extern GameState currentState;

void StateMachine_Update(void);

#endif
