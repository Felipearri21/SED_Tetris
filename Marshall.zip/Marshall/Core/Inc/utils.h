/*
 * utils.h
 *
 *  Created on: Nov 26, 2025
 *      Author: yanko
 */

#ifndef INC_UTILS_H_
#define INC_UTILS_H_



#endif /* INC_UTILS_H_ */
