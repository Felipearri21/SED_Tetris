// actuators.h
#ifndef ACTUATORS_H
#define ACTUATORS_H

#include <stdint.h>

void Actuators_Init(void);
void Led_Central_On(void);
void Led_Central_Off(void);
void Led_Player_Show(uint8_t player);
void Led_ClearAll(void);

/* Buzzer non-blocking */
void Buzzer_PlayTone(uint32_t freq_hz, uint32_t duration_ms);
void Buzzer_PlayMelody(const uint32_t *freqs, const uint32_t *dur_ms);
void Buzzer_Update(void); // llamar frecuentemente desde main loop / fsm_tick

#endif
