#ifndef GAME_H
#define GAME_H

#include "main.h"

typedef enum {
    MODE_DUEL,
    MODE_FASTEST,
    MODE_RANDOM
} GameMode;

extern GameMode currentMode;

void Game_Init(void);
void Game_StartDuel(void);
void Game_Reset(void);

#endif
