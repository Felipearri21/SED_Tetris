// lcd_ui.h
#ifndef LCD_UI_H
#define LCD_UI_H

#include <stdint.h>

typedef enum {
    MODE_CLASSIC = 0,
    MODE_FAST,
    MODE_CUSTOM
} game_mode_t;

typedef struct {
    game_mode_t mode;
    uint8_t rounds;         // rondas a ganar
    uint32_t min_delay_ms;  // mínimo delay aleatorio
    uint32_t max_delay_ms;  // máximo delay aleatorio
} game_config_t;

void LCD_Init_Driver(void);
void LCD_ShowMainMenu(void);
void LCD_ShowWaiting(void);
void LCD_ShowRoundWinner(uint8_t player, uint8_t p1, uint8_t p2);
void LCD_ShowMessage(const char *s);
game_config_t* LCD_GetConfig(void);
void lcd_ui_tick(void);
void lcd_ui_button_event(uint16_t GPIO_Pin);

#endif
