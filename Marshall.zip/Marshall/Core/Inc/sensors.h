// sensors.h
#ifndef SENSORS_H
#define SENSORS_H

#include <stdint.h>

void Sensors_Init(void);
void HAL_GPIO_EXTI_Callback_Custom(uint16_t GPIO_Pin); // implementamos nuestro manejador

#endif
